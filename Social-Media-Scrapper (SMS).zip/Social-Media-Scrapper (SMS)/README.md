# Social Media Scrapper
A powerfull social media web crawler/web scrapper that dumps images, tweets, captions, external links and hashtags from Instagram and Twitter in an organized form. It also shows the most relevant hashtags with their frequency of occurrence in the posts.

## Getting Started

1. Dependencies
Download or Clone the repo, Navigate to the directory containing the files and run the following command in cmd.

python setup.py install

2. Web Driver
After downloading or cloning the repo, Download [chrome webdriver](https://sites.google.com/a/chromium.org/chromedriver/downloads).

3. Twitter App : we need to setup a Twitter App. 
